document.getElementById("tarih").innerText=new Date().toLocaleString("tr-TR");
document.getElementById("servisno").innerText="SRV-"+Date.now();

const canvas=document.getElementById("imza");
const ctx=canvas.getContext("2d");
let d=false;
canvas.onmousedown=e=>{d=true;ctx.beginPath();ctx.moveTo(e.offsetX,e.offsetY)};
canvas.onmousemove=e=>{if(d){ctx.lineTo(e.offsetX,e.offsetY);ctx.stroke()}};
canvas.onmouseup=()=>d=false;

document.getElementById("pdfBtn").onclick=()=>{
  const clone=document.getElementById("form").cloneNode(true);
  const img=document.createElement("img");
  img.src=canvas.toDataURL();
  img.style.width="300px";
  clone.appendChild(img);

  html2pdf().set({
    filename:"Kurumsal_Teknik_Servis_Formu.pdf",
    html2canvas:{scale:2,useCORS:true},
    jsPDF:{unit:"mm",format:"a4"}
  }).from(clone).save();
};

document.getElementById("waBtn").onclick=()=>{
  const m=`TEKNİK SERVİS FORMU
Müşteri: ${ad.value}
Cihaz: ${cihaz.value}
Ücret: ${ucret.value} ₺`;
  window.open("https://wa.me/?text="+encodeURIComponent(m));
};
